package token;

public interface AggAssoc {
    String getFirstName();
    String getSecondName();
}
