/**
 * BNF syntax token expression declarations.
 * Classes in this package are used to represent the abstract syntax tree created when parsing a ucd file.
 */
package parsing.syntaxTree.expressions;