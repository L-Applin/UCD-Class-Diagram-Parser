/**
 * This package offers entry points for parsing the .ucd file
 */
package parsing.syntaxTree;